import java.util.Scanner;

public class Questao2 {
    public static void main(String[] args){
        int A,B,Troca = 0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o valor de A: ");
        A = sc.nextInt();
        System.out.println("Digite o valor de B: ");
        B = sc.nextInt();
        Troca = A;
        System.out.println(  B +" " +Troca);

    }
}
